
<?php
require("database.php");
require("forms/extention_functions.php");
$db = new db();
session_start();
if(isset($_POST["add"]))
{
        $needle = array($_POST["id"],$_POST['quantity']); 
    
    if(isset($_SESSION["cart"]))
    {
        $hay_stack = explode(',',$_SESSION["cart"]); // because $_SESSION can only store strings we turn it into array
        
        if(count($hay_stack) > 0)
        {
           // var_dump(explode(',',$_SESSION['cart']));
            $needle = $needle[0] . ' ' . $needle[1];
            array_push($hay_stack,$needle); 
           $_SESSION["cart"] = implode(',',$hay_stack); // we convert the array back to string seperating each value by comma  
            echo '<script>window.location="/"</script>';
            // if you are submitting a form you don't have to relocate the user
        }
        else if (count($hay_stack) == 1) {
           $needle = $needle[0] . ' ' . $needle[1];
            array_push($needle,$hay_stack);
           $_SESSION["cart"] = implode(',',$hay_stack); // we convert the array back to string seperating each value by comma  
            echo '<script>window.location="/"</script>';
            
        } 
        else
        {
            echo '<script>alert("Products already added to cart")</script>';
            echo '<script>window.location="/"</script>';
        }
    }
    else
    {
       $needle = $needle[0] . ' ' . $needle[1];
        $hay_stack = $needle;
        $_SESSION["cart"] = $hay_stack;
    }
}
if(isset($_GET["action"]))
{
    if($_GET["action"] == "delete")
    {
        $hay_stack = isset($_SESSION['cart']) ? explode(',',$_SESSION["cart"]): array();
        foreach($hay_stack as $key)
        {
            $key = explode(' ',$key); 
            if($key[0] == $_GET["Product_ID"]) // use plural version for less confusion $keys into $key because later you use only one key
            {
                
                array_slice(
                    array_search($key[0] . ' ' . $key[1],$hay_stack),
                     $hay_stack); 
                // var_dump($hay_stack);    // just to be sure we should debug the output here, some behaviour might be unpredictable
            //    echo '<script>alert("Product has been removed")</script>';
            // we want to know the output //  echo '<script>window.location="index.php"</script>';
            }
        }
                $_SESSION['cart'] = $haystack;
        
    }
}
?>
<div style="clear: both"></div>
<div class="container" style="width: 60%;">
        <h2 align="center">My shopping cart</h2>
        </div>
<div class="table-responsive">
    <table class="table table-bordered">
        <tr>
            <th width="30%">Product Name</th>
            <th width="10%">Product ID</th>
            <th width="10%">Quantity</th>
            <th width="20%">Price Details</th>
            <th width="15%">Order Total</th>
            <th width="5%">Action</th>
        </tr>
        <?php
        if(!empty($_SESSION["cart"]))
        {
            $total = 0;
            
            $hay_stack = explode(',',$_SESSION["cart"]);
            $query = "SELECT * FROM Products WHERE Product_ID IN ("; 
            $i = 1;
            $c = count($hay_stack);

            foreach ($hay_stack as $key) {
                $key = explode(' ',$key);
                if ($i++ < $c) {
                $query .= "'" . $key[0] . "',";
                } else {
                    $query .= "'" . $key[0] . "'";
                }
            }
                
   $db->bind(':name',htmlspecialchars(strip_tags($admin_name)));
   $db->bind(':pass',htmlspecialchars(strip_tags($admin_pass)));
   $db->execute();
   

    if($db->rowCount() > 0)
    {
        $result = $db->resultset(); 
                 
            $query .= ") ORDER BY Product_ID ASC";
          //  console($query);
            
           $db->query($query);
           $db->execute();
           $result = $db->resultset();
           if($db->rowCount() > 0)
        {
            $index = 0;
            $total = 0;
            // print_r($result);
            while ($row = $result) {
                $quantity =  explode(' ',$hay_stack[$index])[1] ? explode(' ',$hay_stack[$index])[1]: 0;      

            ?>
                <tr>
                    <td><?php echo $row["Product_name"]; ?></td>
                    <td><?php echo $row["Product_ID"]; ?></td>
                    
                    <td>
                        <a style="cursor:pointer;" class="mini-button plus" data-id="<?php echo $index;?>">+</a>
                        <input min="1" class="quantity quantity-<?php echo $index;?>" type="number" value="<?php echo $quantity ?>" />
                        <a style="cursor:pointer;" class="mini-button minus" data-id="<?php echo $index ;?>">-</a>
                    </td>
                    <td>$ <?php echo $row["price"]; ?></td>
                    <td>$ <?php echo number_format($quantity * $row["price"], 2); ?></td>
                    <td><a href="/shop?action=delete&id=<?php echo $row["Product_ID"]; ?>"><span class="text-danger">X</span></a></td>
                </tr>
            <?php
            $index++;
            $total += $row['price'] * $quantity;
        }
        }
        ?>
              
            <?php
            
            ?>
            <tr>
                <td colspan="3" align="right">Total</td>
                <td align="right">$ <?php echo number_format($total, 2); ?></td>
                <td></td>
            </tr>
        </table>
        </div>
        </div>
            <?php
        }
        else { 
            echo "<div class='container jumbotron'>You have no items in your basket yet. <a href='/'>Take a look in the shop</a></div>";
        }
        $db = null;
        ?>
<script>
    $('.mini-button').on('click',function(){
            console.log('click');
        var quantity = $(this).siblings('.quantity');
        var value = parseInt($(quantity).attr('value'));
        
        if($(this).hasClass("plus")) {
            console.log(value,'value');
            $(quantity).attr('value', value + 1);
        }
   
        else if(value > 1) {
            $(quantity).attr('value',value - 1);
        }
    });
</script>

