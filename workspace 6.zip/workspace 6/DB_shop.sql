
DROP DATABASE if EXISTS `RubbyDuck`;
CREATE DATABASE `RubbyDuck`;
Use `RubbyDuck`;

CREATE TABLE `Postal_code` (
    Postal_code_ID VARCHAR(11) NOT NULL PRIMARY KEY,
    City varchar(255)

);

CREATE TABLE `Address`(

    Address_ID int(11) AUTO_INCREMENT NOT NULL PRIMARY KEY,
    Street varchar(255),
    Country varchar(255),
    Postal_code_ID varchar(11) NOT NULL,
    FOREIGN KEY (Postal_code_ID) REFERENCES Postal_code(Postal_code_ID)
);

CREATE TABLE `Customers`(
    Customer_ID int(11) AUTO_INCREMENT NOT NULL PRIMARY KEY,
    Password varchar(255),
    Email varchar (255),
    Nick_name varchar(255),
    First_name varchar(255),
    Last_name varchar(255),
    Address_ID int(11) NOT NULL,
    FOREIGN KEY (Address_ID) REFERENCES Address (Address_ID)

);
 CREATE TABLE `Orders`(
   Order_ID int (11)  AUTO_INCREMENT NOT NULL PRIMARY KEY,
   Quantity int (15),
   Price DECIMAL(4,2),
   Customer_ID INT (11) NOT NULL,
   Date TIMESTAMP,
   FOREIGN KEY (Customer_ID) REFERENCES Customers (Customer_ID)

 );
CREATE TABLE `Category`(
  Category_ID INT(11) AUTO_INCREMENT NOT NULL PRIMARY KEY,
  Type VARCHAR(255)
);

CREATE TABLE `Products`(
  Product_ID INT(11)  AUTO_INCREMENT NOT NULL PRIMARY KEY,
  Product_name VARCHAR(255),
  price DECIMAL(4,2),
  image VARCHAR(255),
  Category_ID INT (11),
  Quantity INT(11),
  FOREIGN KEY (Category_ID) REFERENCES Category(Category_ID)

);

CREATE TABLE `ORDERED` (
  Quantity INT(11),
  Product_ID INT(11)NOT NULL,
  Customer_ID INT (11) NOT NULL,
  CONSTRAINT PK_ORDERED PRIMARY KEY (Product_ID,Customer_ID),
  FOREIGN KEY (Product_ID) REFERENCES Products (Product_ID),
  FOREIGN KEY (Customer_ID) REFERENCES Customers(Customer_ID)

);
CREATE TABLE `Company`(
  Company_ID INT(11)NOT NULL PRIMARY KEY,
  Description VARCHAR(255),
  Name VARCHAR(255),
  Contact VARCHAR(255),
  Street VARCHAR(255),
  Country VARCHAR(255),
  Postal_code_ID VARCHAR(11),
  FOREIGN KEY(Postal_code_ID)REFERENCES Postal_code (Postal_code_ID)

);

CREATE TABLE `Admin`(
  Admin_ID INT(11)AUTO_INCREMENT PRIMARY KEY,
  Name VARCHAR(255) NOT NULL ,
  Email VARCHAR(255),
  Password VARCHAR(255) NOT NULL,
  Nick_name VARCHAR(255) NOT NULL

);

CREATE TABLE `NEWS`(
  NEWS_ID INT(11)NOT NULL PRIMARY KEY,
  Content TEXT,
  Date TIMESTAMP
  );


INSERT INTO `Postal_code` (`Postal_code_ID`, `City`) VALUES
  ('6700', 'Esbjerg'),
  ('6705', 'Esbjerg Ø'),
  ('6710', 'Esbjerg V'),
  ('43401','Most'),
  ('1100','Prague 1'),
  ('NW10','London');

INSERT INTO `Address` (`Address_ID`,`Street`,`Country`,`Postal_code_ID`) VALUES
  (NULL, 'Kongensgade 100','Denmark','6700'),
  (NULL, 'Stormgade 50','Denmark','6700');

INSERT INTO `Customers` (Customer_ID, Password, Email, Nick_name, First_name, Last_name, Address_ID) VALUES
  (NULL, '123456','mxm969@seznam.cz','John_kostka','John','Brick','1');

INSERT INTO `Orders`(`Order_ID`,`Price`,`Customer_ID`) VALUES
  ('1','3.79','1');

INSERT INTO `Category`(Category_ID,Type) VALUES
  ('1','Regular duck'),
  ('2','Theme duck'),
  ('3','Heart duck');

INSERT INTO `Products`(Product_ID, Product_name, price, image, Category_ID,Quantity) VALUES
  (NULL ,'Dragon duck','3.69','images/dragon_duck.png','1','10'),
  (NULL,'Cosmo duck','3.69','images/cosmo_duck.png','2','5'),
  (NULL,'Cop duck','3.89','images/cop_duck.png','2','12'),
  (NULL,'Black Duck','2.49','images/black_duck.png','1','20'),
  (NULL,'Leopard Duck','2.49','images/leopard_duck.png','1','15'),
  (NULL,'Zig zag  Duck','2.49','images/zig_zag_duck.png','1','15'),
  (NULL,'London theme duck','3.89','images/london_duck.png','2','5');




INSERT INTO `Company`(Company_ID, Description, Contact,Street,Country,Postal_code_ID) VALUES
  ('1', 'Rubby the duck is new estabished company selling unique rubber duck. We are first on the market with our extraordinary offer of all types of rubber duck. Feel free to explore our products or ask if any help needed.
Have fun!','Camila.jones@rubbytheduck.com ','Manseova 3','United Kingdom','NW10');

INSERT INTO `Admin` (Name, Email, Password,Nick_name) VALUES

  ('Barbora','Daffy94@seznam.cz','1A2B3C4D5E6F0','Barbora_1');
  
INSERT INTO `Admin` (Name, Email, Password,Nick_name) VALUES

  ('i','i','i','i');


INSERT INTO `NEWS` ( Content,Date ) VALUES  
('Have you heard it? Our shop gained a lot of fans and enthusiastic during only one year on the market! You have been such amazing customers, and we love your support not only on our e-shop and facebook. So we decided to celebrate our second birthday with you by opening a first souvenir shop in the center of London! You will have the change to buy our unique theme ducks such as Rubby Duck Space Duck, Great Britain Duck, Duck Cowboy Duck, and Chief Duck. We can not wait to see you personally and welcome you to the grand opening- 1st of July 2018, on Manesova 8, London UK. Make sure you will not miss a unique chance to buy exclusive theme ducks, and as a bonus, we will introduce a limited edition of rubber duck for this year.','CURRENT_TIMESTAMP');

