
/**
 * Created by PhpStorm.
 * User: applelevne
 * Date: 11/04/2018
 * Time: 16.52
 
*/
<?php
$_SESSION= array();
unset ($_COOKIE["user"]);
if (isset $_COOKIE[session_name()])){
    setcookie(session_name(),'',time()-42000,'/',$_SERVER["HTTP_HOST"]);
}
?>
