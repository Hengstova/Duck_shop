<?php /*
session_start();
include_once('../database.php');
    $db = new db();
?>
 <html>
<head lang="en">
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <title>View Users</title>
</head>
<style>
    .login-panel {
        margin-top: 150px;
    }
    .table {
        margin-top: 50px;

    }

</style>

<body>

<div class="table-scrol">
    <h1 align="center">All the Users</h1>

<div class="table-responsive"><!--this is used for responsive display in mobile and other devices-->


    <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">
        <thead>

        <tr>

            <th>User Id</th>
            <th>User E-mail</th>
            <th>User Nickame</th>
            <th>User First Name</th>
            <th>User Last Name</th>
            <th>Adress</th>
            <th>Delete User</th>
        </tr>
        </thead>

        <?php
      
        $view_users_query="select * from Customers";//select query for viewing users.
        $run=mysqli_query($db,$view_users_query);//here run the sql query. -- how

        while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
        {
            $user_id=$row[0];
            $user_name=$row[1];
            $user_email=$row[2];
            $user_nickname=$row[3
            $user_fname=$row[4];
            $user_lname=$row[5];
            $adress=$row[6];




        ?>

        <tr>
<!--here showing results in the table -->
            <td><?php echo $user_id;  ?></td>
            <td><?php echo $user_email;  ?></td>
            <td><?php echo $user_nickname;  ?></td>
            <td><?php echo $user_fname;  ?></td>
            <td><?php echo $user_lname;  ?></td>
            <td><?php echo $adress;  ?></td>
            <td><a href="delete.php?del=<?php echo $user_id ?>"><button class="btn btn-danger">Delete</button></a></td> <!--btn btn-danger is a bootstrap button to show danger-->
        </tr>

        <?php } ?>

    </table>
        </div>
</div>


</body>

</html>
*/?>

<?php 
session_start();
include_once('../database.php');
    $db = new db();
    ?>
<!DOCTYPE html>
<html>
    <head lang="en">
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel= stylesheet type="text/css" href="../style.css">
    <title>All users</title>
</head>
<body>
    
<div class="logo"><a href="index.php"></a> <img src="../images/Webshop_1_03.gif"></div>
<ul class="nav">
        <li><a href="../CRUD_duck/index.php">Products</a></li>
        <li><a href="../CRUD_duck/orders.php">Orders</a></li>
        <li><a href="view_users.php">Users</a></li>
        <li><a href= "admin_login.php">Log out</a></li> <!-- notif. Alert + add session-->
        
    </ul>

<div class="table-scrol">
    <h1 align="center">All Users</h1>

<div class="table-responsive">


    <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">
        <thead>

        <tr>

            <th>Customer_ID</th>
            <th>E-mail</th>
            <th>Nick Name</th>
            <th>First Name</th>
            <th>Last Name</th>
            
        </tr>
        </thead>
<?php

class TableRows extends RecursiveIteratorIterator { 
    function __construct($it) { 
        parent::__construct($it, self::LEAVES_ONLY); 
    }

    function current() {
        return "<td style='width: 150px; border: 1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() { 
        echo "<tr>"; 
    } 

    function endChildren() { 
        echo "</tr>" . "\n";
    } 
} 


//$servername = "localhost";
//$username = "root";
//$password = "root";
//$dbname = "RubbyDuck";

// try {
//     $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
//     $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//     $stmt = $conn->prepare("SELECT Customer_ID,Email,First_name,Last_name,Adress_ID FROM Customers"); 
//     $stmt->execute();

//     // set the resulting array to associative
//     $result = $stmt->setFetchMode(PDO::FETCH_ASSOC); 
$db->query("SELECT Customer_ID,Email,Nick_name,First_name,Last_name FROM Customers");
$db->execute();
 
    foreach(new TableRows(new RecursiveArrayIterator($db->resultset())) as $k=>$v) { 
        echo $v;
    }
// }
// catch(PDOException $e) {
//     echo "Error: " . $e->getMessage();
// }
//$conn = null;
/*
echo "</table>";
// sql to delete a record
    $sql = "DELETE FROM Customers WHERE Customer_ID";

    // use exec() because no results are returned
    $conn->exec($sql);
    echo "Record deleted successfully";
    }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }

$conn = null;?>*/

?> 

</body>
</html>