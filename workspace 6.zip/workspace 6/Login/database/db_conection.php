<?php
/**
 * Created by PhpStorm.
 * User: applelevne
 * Date: 12/04/2018
 * Time: 17.49
 */

// $dbcon=mysqli_connect("localhost","root","root");

// mysqli_select_db($dbcon,"RubbyDuck");

?>