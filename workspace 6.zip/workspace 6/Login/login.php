<?php
session_start();//session starts here
include_once('../database.php');
$db = new db();
?>



<html>
<head lang="en">
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <title>Log in</title>
</head>
<style>
    .login-panel {
        margin-top: 150px;
}
</style>

<body>


<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="login-panel panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title">Sign In</h3>
                </div>
                <div class="panel-body">
                    <form role="form" method="post" action="login.php">
                        <fieldset>
                            <div class="form-group"  >
                                <input class="form-control" placeholder="E-mail" name="email" type="email" autofocus>
                            </div>
                            <div class="form-group">
                                <input class="form-control" placeholder="Password" name="pass" type="password" value="">
                            </div>


                                <input class="btn btn-lg btn-success btn-block" type="submit" value="login" name="login" >

                            <!-- Change this to a button or input when using this as a form -->
                         <!-- <a href="index.html" class="btn btn-lg btn-success btn-block">Login</a>-->
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


</body>

</html>

<?php
if(isset($_POST['login']))//this will tell us what to do if some data has been post through form with button.
{
    $email=$_POST['email'];
    $pass=$_POST['pass'];

   $db->query("SELECT * from Customers WHERE Email=:email AND Password=:pass");
   $db->bind(':email',htmlspecialchars(strip_tags($email)));
   $db->bind(':pass',htmlspecialchars(strip_tags($pass)));
   $db->execute();
   

    if($db->rowCount() > 0)
    {
        $result = $db->resultset();
        $_SESSION['login'] = $result['Customer_ID'];// 

    echo "<script>window.open('../index.php','_self')</script>"; //  print out the name ?
    
    }
    else {
        echo"<script>alert('Your details are incorrect!')</script>";
        
    }

}

?>
<?php

/*if(isset($_POST['login']))
{
    $user_email=$_POST['email'];
    $user_pass=$_POST['pass'];

    $check_user="select * from Customers WHERE Email='$user_email'AND Password='$user_pass'";

    $run=mysqli_query($dbcon,$check_user);

    if(mysqli_num_rows($run))
    {
        echo "<script>window.open('welcome.php','_self')</script>";

      php  $_SESSION['email']=$user_email;//here session is used and value of $user_email store in $_SESSION.

    }
    else
    {
        echo "<script>alert('Email or password is incorrect!')</script>";
    }
}*/
?>