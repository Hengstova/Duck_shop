<?php 
session_start();
include_once('../database.php');
    $db = new db();
    ?>
<!DOCTYPE html>
<html>
    <head lang="en">
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel= stylesheet type="text/css" href="../style.css">
    <title>All products</title>
</head>
<body>
 


<div class="table-scroll">
    <h1 align="center">All Products</h1>

<div class="table-responsive"><!--this is used for responsive display in mobile and other devices-->


    <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">
        <thead>

        <tr>

            <th>Product ID</th>
            <th>Name</th>
            <th>Price</th>
            <th>In Stock</th>
            <th>Action</th>
            <!--<button class="waves-effect waves-light btn" type='delete'>Delete</button>-->
            
            
        </thead>
<?php

class TableRows extends RecursiveIteratorIterator { 
    function __construct($it) { 
        parent::__construct($it, self::LEAVES_ONLY); 
    }

    function current() {
        return "<td style='width: 150px; border: 1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() { 
        echo "<tr>"; 
    } 

    function endChildren() { 
        echo "</tr>" . "\n";
    } 
} 

$db->query("SELECT Product_ID, Product_name,price,Quantity FROM Products");//? join for category
$db->execute();
 
    foreach(new TableRows(new RecursiveArrayIterator($db->resultset())) as $k=>$v) { // for each - button
        echo $v;
      
         }
         
    
         
    ?>
   
                    
                    <a type='submit'  class='btn btn-danger' name='delete'>Delete</a>
            
    
      <td>
                       
                    <a href='admin/product/update' type='submit'  class='btn btn-info' name='update'>Update</a> <!-- redirect to index in CRUD folder-->
              </td>
                

<a href='/admin/detail' type='submit' class='btn btn-primary m-r-1em' name='detail'>Detail</a>
<?php 
?>
              
 <?php  
if  (isset($_POST['delete'])){
    

$db->query("DELETE FROM Products WHERE Product_ID=:id");
$db->bind(':id',$someId);
$db->execute();
if($db->execute()){
                echo "<div class='alert alert-success'>Product was deleted.</div>";
            }else{
                echo "<div class='alert alert-danger'>Unable to delete the product.</div>";
            }
}
?> 

                   

              <a href='/admin/product/create' class='btn btn-primary' name='create'>Create new product</a> 
              <!-- redirect to index in CRUD folder-->
             
                   
</html>
