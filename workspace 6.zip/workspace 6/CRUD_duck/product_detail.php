<?php 
session_start();
include_once('../database.php');
    $db = new db();
    ?>
<!DOCTYPE html>
<html>
    <head lang="en">
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel= stylesheet type="text/css" href="../style.css">
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <title>Product detail</title>
</head>
<body>
    
<div class="logo"><a href="index.php"></a> <img src="../images/Webshop_1_03.gif"></div>
<ul class="nav">
        <li><a href="index.php">Products</a></li>
        <li><a href="orders.php">Orders</a></li>
        <li><a href="../Login/view_users.php">Users</a></li>
        <li><a href= "../Login/admin_login.php">Log out</a></li> <!-- notif. Alert + add session-->
        
    </ul>
<div class="table-scrol">
    <h1 align="center">Product Detail</h1>

<div class="table-responsive"><!--this is used for responsive display in mobile and other devices-->


    <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">
        <thead>

        <tr>

            <th>Product ID</th>
            <th>Name</th>
            <th>Image</th>
            <th>Price</th>
            <th>Category</th>
            <th>Quantity</th>
            
</tr>
</thead>



        
        </html>
                