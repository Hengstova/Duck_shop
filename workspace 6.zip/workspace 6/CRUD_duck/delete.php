<?php
/* include database connection
include '../database.php';
 
try {
     
    // get record ID
    // isset() is a PHP function used to verify if a value is there or not
    $id=isset($_GET['id']) ? $_GET['id'] : die('ERROR: Record ID not found.');
 
    // delete query
    $query = "DELETE FROM Products WHERE Product_ID = Product_ID LIMIT 1 "; //$sql = "DELETE FROM 'tbl_products' WHERE 'ProductID' = ProductID LIMIT 1";
    $stmt = $con->prepare($query);
    $stmt->bindParam(1, $id);
     
    if($stmt->execute()){
        // redirect to read records page and 
        // tell the user record was deleted
        header('Location: index.php?action=deleted');
    }else{
        die('Unable to delete record.');
    }
}
 
// show error
catch(PDOException $exception){
    die('ERROR: ' . $exception->getMessage());
}
*/?> 

<?php 
session_start();
include_once('../database.php');
    $db = new db();
    
    $db ->query("DELETE FROM Products WHERE Product_ID = Product_ID LIMIT 1");
    $db = $databaseConnection->prepare($sql);//nope
    $db->bindParam(':Product_ID', $_POST['Product_ID'], PDO::PARAM_INT);
    $db->execute();
    if ($db->execute()) {
        echo "<div class='alert alert-success'>Product deleted</div>";
    }else{
        echo"<div class='alert alert-danger'>Unable to delete the product</div>";
    }

header('Location: index.php');

?>

