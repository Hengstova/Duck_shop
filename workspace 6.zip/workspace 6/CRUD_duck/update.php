<?php

include_once('../forms/extention_functions.php'); 
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Update</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel= stylesheet type="text/css" href="style.css">
</head>
<!--project-->
    <body>
<?php 
$form_structure = array(
        "Product name" => array(
            "value" => "",//SELECT Product_name FROM Products WHERE Product_ID= ",// DB 
            "placeholder" => "Product name*",
            "type" => "text"
             ),
        "Price" => array(
            "value" => "",
            "placeholder" => "Price*",
            "type" => "number"
             ),
        "Image" => array(
            "value" => "",
            "placeholder" => "image",
            "type" => "file"
             ),
        "Category"=> array(
            "value"=>"",
            "placeholder"=>"Category",
            "type" =>"text"// how drop down or so 
              ),
        "Quantity"=> array(
            "value"=>"",
            "placeholder"=>"Quantity",
            "type" =>"number"
            )
            
    );
    

?>
<div class="jumbotron container">
<?php
form($form_structure, '/index.php'); //change
?>
<p>By saving you are updating data of products</p>
</div>


    </body>
</html>

<!-- $handle= $con->prepare ("UPDATE savingsacc.. SET balance =balance -100");-->