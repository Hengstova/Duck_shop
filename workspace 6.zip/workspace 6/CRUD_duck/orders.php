<?php 
session_start();
include_once('../database.php');
    $db = new db();
    ?>
<!DOCTYPE html>
<html>
    <head lang="en">
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
     <link rel= stylesheet type="text/css" href="../style.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <title>All orders</title>
</head>
<body>
    
<div class="logo"><a href="index.php"></a> <img src="../images/Webshop_1_03.gif"></div>
<ul class="nav">
        <li><a href="index.php">Products</a></li>
        <li><a href="orders.php">Orders</a></li>
        <li><a href="../Login/view_users.php">Users</a></li>
        <li><a href= "../Login/admin_login.php">Log out</a></li> <!-- notif. Alert + add session-->
        
    </ul>
<div class="table-scrol">
    <h1 align="center">Orders</h1>

<div class="table-responsive"><!--this is used for responsive display in mobile and other devices-->


    <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">
        <thead>

        <tr>

            <th>Order ID</th>
            <th>Customer ID</th>
            <th>Order Date</th>
    
          </tr>  
        </thead>
       <?php

class TableRows extends RecursiveIteratorIterator { 
    function __construct($it) { 
        parent::__construct($it, self::LEAVES_ONLY); 
    }

    function current() {
        return "<td style='width: 150px; border: 1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() { 
        echo "<tr>"; 
    } 

    function endChildren() { 
        echo "</tr>" . "\n";
    } 
} 
$db->query("SELECT Order_ID,Customer_ID,Date FROM Orders");
$db->execute();
 
    foreach(new TableRows(new RecursiveArrayIterator($db->resultset())) as $k=>$v) { 
        echo $v;
        
    }
        ?>
        
        </html>