<?php
// used to connect to the database
// $host = "localhost";
// $db_name = "RubbyDuck";
// $username = "root";
// $password = "root";


    // try {
//     $con = new PDO("mysql:host={$host};dbname={$db_name}", $username, $password);
// }

// // show error
// catch(PDOException $exception){
//     echo "Connection error: " . $exception->getMessage();
// }

// $GLOBALS['config'] = array(
//     "database" => array(
//         "host" => getenv('IP'),
//         "username" => getenv('C9_USER'),
//         "password" => "",
//         "name" => "RubbyDuck",
//         "database_port" => 3306
//     ),
//     "otherSettings" => array(
//         "groupOfSettings" => 'someValues'
//         )
// );
define('DB_HOST',getenv('IP'));
define('DB_USER',getenv('C9_USER'));
define('DB_PASS',"");
define('DB_NAME',"RubbyDuck");
define('DB_PORT',3306);
// try {

//     $con_str = "mysql:host=";
//     $con_str += ;
//     $con_str += ';port=';
//     $con_str += ;
//     $con_str += ";dbname=";
//     $con_str += ;

//     $con = new PDO(
//         $con_str,
//         ,
//         );
// }

// // show error
// catch(PDOException $exception){
//     echo "Connection error: " . $exception->getMessage();
// }

?>

<?php
class db{
    private $host = DB_HOST;
    private $port = DB_PORT;
    private $dbName = DB_NAME;
    private $user = DB_USER;
    private $pass = DB_PASS;

    private $dbh;
    private $error;
    private $qError;

    private $stmt;

    public function __construct(){
        //dsn for mysql
        $dsn = "mysql:host=".$this->host."; dbname=".$this->dbName;
        $options = array(
            PDO::ATTR_PERSISTENT    => true,
            PDO::ATTR_ERRMODE       => PDO::ERRMODE_EXCEPTION
        );

        try{
            $this->dbh = new PDO($dsn, $this->user, $this->pass, $options);
        }
            //catch any errors
        catch (PDOException $e){
            $this->error = $e->getMessage();
        }

    }

    public function query($query){
        $this->stmt = $this->dbh->prepare($query);
    }

   public function bind($param, $value, $type = null){
        if(is_null($type)){
            switch (true){
                case is_int($value):
                    $type = PDO::PARAM_INT;
                    break;
                case is_bool($value):
                    $type = PDO::PARAM_BOOL;
                    break;
                case is_null($value):
                    $type = PDO::PARAM_NULL;
                    break;
                default:
                    $type = PDO::PARAM_STR;
            }
        }
        $this->stmt->bindValue($param, $value, $type);
    }

    public function execute(){
        return $this->stmt->execute();

        $this->qError = $this->dbh->errorInfo();
        if(!is_null($this->qError[2])){
            echo $this->qError[2];
        }
        echo 'done with query';
    }

    public function resultset(){
        $this->execute();
        return $this->stmt->fetchAll(PDO::FETCH_ASSOC); // fetchALL!
    }

    public function single(){
        $this->execute();
        return $this->stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function rowCount(){
        return $this->stmt->rowCount();
    }

    public function lastInsertId(){
        return $this->dbh->lastInsertId();
    }

    public function beginTransaction(){
        return $this->dbh->beginTransaction();
    }

    public function endTransaction(){
        return $this->dbh->commit();
    }

    public function cancelTransaction(){
        return $this->dbh->rollBack();
    }

    public function debugDumpParams(){
        return $this->stmt->debugDumpParams();
    }

    public function queryError(){
        $this->qError = $this->dbh->errorInfo();
        if(!is_null($qError[2])){
            echo $qError[2];
        }
    }

}//end class db
?>