<?Php
echo "<br><br><input type=button 
onClick=window.open(\"rating-window.php?page_name=$page_name\",\"Ratting\",\"width=550,height=170,left=150,top=200,toolbar=0,status=0\"); value=\"Rate this product\">
<br><br>
";
?>