<?php
//copy paste the info from the file "constants.php" in here
// require("constants.php");
// $connection = new mysqli(
//     $GLOBALS['config']['database']['host'],
//     $GLOBALS['config']['database']['username'],
//     $GLOBALS['config']['database']['password'],
//     $GLOBALS['config']['database']['name'],
//     $GLOBALS['config']['database']['database_port']);
// if ($connection->connect_error)
// {
//     die('Could not connect to the DB');
// }
// else if (!$connection) {
//     die('Close if not connected');
// }

// die if there is no db


