<?php
// define ("DB_server","localhost");
// define( "DB_USER","root");
// define("DB_PASS","root");
// define("DB_NAME","RubbyDuck");

// don't make a habit of it that is usually a bad practice that is not encouraged 
// a way better approach would be to use $GLOBAL attribute and then safely move the whole tree of settings
// like so:

$GLOBALS['config'] = array(
    "database" => array(
        "host" => getenv('IP'),
        "username" => getenv('C9_USER'),
        "password" => "",
        "name" => "RubbyDuck",
        "database_port" => 3306
    ),
    "otherSettings" => array(
        "groupOfSettings" => 'someValues'
        )
);