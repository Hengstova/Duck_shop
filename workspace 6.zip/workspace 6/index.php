<?php
require_once('forms/load.php');
session_start();
define('HOST','https://cms-barbarian-beatons.c9users.io/');
 function getCurrentUri()
    {
        $basepath = implode('/', array_slice(explode('/', $_SERVER['SCRIPT_NAME']), 0, -1)) . '/';
        $uri = substr($_SERVER['REQUEST_URI'], strlen($basepath));
        if (strstr($uri, '?')) $uri = substr($uri, 0, strpos($uri, '?'));
        $uri = '/' . trim($uri, '/');
        return $uri;
    }

    $base_url = getCurrentUri();
    $unclean_routes = array();
    $unclean_routes = explode('/', $base_url);
    $routes = array();
    foreach($unclean_routes as $route)
    {
        
        if(trim($route) !== '') { 
            
            array_push($routes, $route);
        }
   }
    if ($routes[0] === 'admin' && !isset($SESSION['admin'])){ //session is not set, nav to hp
       header('Location: '. HOST);
        
    } 
   if($routes[0] == '') {
      $routes = array('home');//no route- nav to the home
        }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Rubby the Duck </title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="/style.css" />
</head>
<!--project-->
    
   <body>
       
       <?php 
      
        if(isset($_SESSION['admin'])) {
            load::view('admin/admin_navigation');
        }  else {
            load::view('templates/navigation');
        }
            

//   var_dump($routes);

    /*
    Now, $routes will contain all the routes. $routes[0] will correspond to first route.
    For e.g. in above example $routes[0] is search, $routes[1] is book and $routes[2] is fitzgerald
    */
            if(file_exists( $file = 'pages/' . implode('/',$routes) . '.php')) {
                // echo $file;
                require_once $file;
            }  
            else
            { 
                // echo $file;
                echo 'not found';
            }
       ?>
       
    </body>



</html>