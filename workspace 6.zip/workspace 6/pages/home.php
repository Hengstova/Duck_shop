 <?php 
require "database.php";
 
 $db = new db();
 ?>
        <h1 class="main-text">RUBBY THE DUCK</h1>
   
        <h2 class="header-text text-center">About Us</h2>
        <?php
        $db->query("SELECT * FROM Company");
        $db->execute();
       
        if($db->rowCount() > 0) {
            $single = $db->single();



                ?>
                <p class="pad text-center"> <?php echo $single["Description"]; ?></p>
                <?php
            }
        ?>
        
        
   
        <h2 class="header-text text-center">News</h2>
        <?php
        $db->query("SELECT * FROM NEWS");
        $db->execute();
       
        if($db->rowCount() > 0) {
            $single = $db->single();



                ?>
                <p class="pad text-center"> <?php echo $single["Content"]; ?></p>
                <?php
            }
        ?>
   
    
        <h2 class="header-text text-center">Special Offers</h2>
    
    <p class="paragraph-text" align="center">
       Don't miss out chance to buy our unique theme ducks! 
       </p>
       <div class="container">
           

       <!-- spec. ducks -- Rubby Duck Space Duck, Great Britain Duck, Duck Cowboy Duck and Chief Duck.-->
    <?php

        $db->query("SELECT * FROM Products WHERE Category_ID=2");
        $db->execute();
        if($db->rowCount() > 0)
        {
            $output = ''; 
            foreach ($db->resultset() as $row ) {
           $output .=  '<div class="three-item">
                <form method="post" action="/shop">
                    <input 
                    type="hidden" 
                    name="id" 
                    value="'. $row['Product_ID'] . '" />
                    <div 
                    style="border:1px solid #eaeaec; margin: -1px 19px 3px -1px; box-shadow: 0 1px 2px rgba(0,0,0,0.05);padding: 10px;"
                         align="center">
                        <img src="' .  $row['image'] .'" class="product-img img-responsive" />
                        <h5 class="text-info">' .  $row['Product_name'] .'</h5>
                        <h5 class="text-danger">$ ' .  $row['price'] .'</h5>
                        <input type="text" name="quantity" class="form-control" value="1" />
                        <input type="hidden" name="hidden_name" value="'.$row['Product_name'].'" />
                        <input type="hidden" name="hidden_price" value="'. $row['price'].'" />
                        <button type="submit" name="add" style="margin-top:5px;" class="btn-btn-default">Add to Bag</button>
                     
                    </div>
                </form>
            </div>';
            
        }
        echo $output;
        }
?>
       </div>
<!--shop -->
    <h2 class="header-text text-center full" name ="products">Products</h2>
    <div class="container" >
          <?php

        $db->query("SELECT * FROM Products ORDER BY Product_ID ASC");
        $db->execute();
        if($db->rowCount() > 0)
        {
            $output = ''; 
            foreach ($db->resultset() as $row ) {
           $output .=  '<div class="col-md-4">
                <form method="post" action="/shop">
                    <input 
                    type="hidden" 
                    name="id" 
                    value="'. $row['Product_ID'] . '" />
                    <div 
                    style="border:1px solid #eaeaec; margin: -1px 19px 3px -1px; box-shadow: 0 1px 2px rgba(0,0,0,0.05);padding: 10px;"
                         align="center">
                        <img src="' .  $row['image'] .'" class="product-img img-responsive" />
                        <h5 class="text-info">' .  $row['Product_name'] .'</h5>
                        <h5 class="text-danger">$ ' .  $row['price'] .'</h5>
                        <input type="text" name="quantity" class="form-control" value="1" />
                        <input type="hidden" name="hidden_name" value="'.$row['Product_name'].'" />
                        <input type="hidden" name="hidden_price" value="'. $row['price'].'" />
                        <button type="submit" name="add" style="margin-top:5px;" class="btn-btn-default">Add to Bag</button>
                        <br><br><input type=button 
onClick=window.open("rating-v3/rating-window.php?page_name=$page_name\",\"Ratting\",\"width=550,height=170,left=150,top=200,toolbar=0,status=0\"); value="Rate this product">
<br><br>

                    </div>
                </form>
            </div>';
            
        }
        echo $output;
        }
    
        ?>
    <div class="container" style="width:60%;">
        <h2 align="center">You might like: </h2>
    </div>
    <!-- recomendation system ( either showing duck from the dsame category or based on last viewed things -->

    <div class="helvetica" style="width:60%">
    <p align="center">Please note the Rubby Duck range is primarily intended as a collectable item only. Due to bespoke shapes, 
especially with some of the more elaborate mouldings and designs with hats, they will not float upright in the bath...
although you are more than welcome to take them for a dip in a Bert & Ernie Rubber Duckie style.</p>
</div>
