<?php
require_once('database.php');
$db = new db();




if(isset($_POST['login']))//this will tell us what to do if some data has been post through form with button.
{
    $email=$_POST['email'];
    $pass=$_POST['pass'];

   $db->query("SELECT * from Customers WHERE Email=:email AND Password=:pass");
   $db->bind(':email',htmlspecialchars(strip_tags($email)));
   $db->bind(':pass',htmlspecialchars(strip_tags($pass)));
   $db->execute();
   

    if($db->rowCount() > 0)
    {
        $result = $db->resultset();
        $_SESSION['login'] = $result['Customer_ID'];// 

    echo "<script>window.open('/','_self')</script>"; //  print out the name ?
    
    }
    else {
        echo"<script>alert('Your details are incorrect!')</script>";
        
    }

}




if (isset($_POST['register'])) {
    
 load::view('user/create_user');
}
else {
    load::view('templates/login'); 
}

    $db = null;
?>
<?php

?>