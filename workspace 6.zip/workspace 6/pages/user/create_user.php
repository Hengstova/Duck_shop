<?php 
session_start();
include_once('database.php');
    $db = new db();
?>
<style>
    .login-panel {
        margin-top: 150px;
}
</style>
<body>

<div class="container"><!-- container class is used to centered  the body of the browser with some decent width-->
    <div class="row"><!-- row class is used for grid system in Bootstrap-->
        <div class="col-md-4 col-md-offset-4"><!--col-md-4 is used to create the no of colums in the grid also use for medimum and large devices-->
            <div class="login-panel panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title">Registration</h3>
                </div>
                <div class="panel-body">
                    <form role="form" method="post">
                        <fieldset>
                            <div class="form-group">
                                <input class="form-control" placeholder="Nick name" name="name" type="text" autofocus>
                            </div>
                            <div class="form-group">
                                <input class="form-control" placeholder="First name" name="fname" type="text" autofocus>
                            </div>
                            <div class="form-group">
                                <input class="form-control" placeholder="Last name" name="lname" type="text" autofocus>
                            </div>
                            <div class="form-group">
                                <input class="form-control" placeholder="E-mail" name="email" type="email" autofocus>
                            </div>
                            <div class="form-group">
                                <input class="form-control" placeholder="Password" name="pass" type="password" value="">
                            </div>


                            <input class="btn btn-lg btn-success btn-block" type="submit" value="register" name="register" >

                        </fieldset>
                  
                    </form>
                    <form role="form" method="post">
                        
                    <fieldset>
                          <center><b>Already registered ?</b> <br></b><button class="btn btn-lg btn-success btn-block" name="login_show">Login here</button></center><!--for centered text-->
                    </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</body>

</html>

<?php

if(isset($_POST['register']))
{  
     try{
            
            // insert query
            $query = "INSERT INTO Customers (Nick_name,First_name,Last_name,Email,Password)VALUES(:name,fname:,:lname,:email,:password)";
            $db->query($query);
            $db->bind(':name',htmlspecialchars(strip_tags($_POST['name'])));
            $db->bind(':fname',htmlspecialchars(strip_tags($_POST['fname'])));
            $db->bind(':lname',htmlspecialchars(strip_tags($_POST['lname'])));
            $db->bind(':email',htmlspecialchars(strip_tags($_POST['email'])));
            $db->bind(':password',htmlspecialchars(strip_tags($_POST['password'])));
         

            
            if($db->execute()){
                echo "<div class='alert alert-success'>Your details were saved.</div>";
                //echo"<script>window.open('/')</script>";//change ? redirect to login or main page
            }else{
                echo "<div class='alert alert-danger'>Unable to save!.</div>";
            }

        }

            // show error
        catch(PDOException $exception){
            die('ERROR: ' . $exception->getMessage());
        }
 
    }
    if(!isset ($_POST['name']))
    {
        echo"<script>alert('Please enter the Nick name')</script>";
exit();//this use if first is not work then other will not show
    }
    
    if(!isset ($_POST['fname']))
    {
        echo"<script>alert('Please enter your First name)</script>";
exit();
    }
    if(!isset ($_POST['lname']))
    {
        echo"<script>alert('Please enter your last name ')</script>";
exit();
    }
    if(!isset ($_POST['email']))
    {
        echo"<script>alert('Please enter the password')</script>";
exit();
    }
    
    if(!isset ($_POST['password']))
    {
        echo"<script>alert('Please enter the email')</script>";
    exit();
    }
    
    
    
//query check weather if user already registered
    $query="SELECT * from Customers WHERE Email=:email";
    $db->query($query);
            $db->execute();

    if($db->rowCount() > 0) 
    {
echo "<script>alert('Email :email is already exist in our database, Please try another one!')</script>";
exit();
    }




?>
