<?php 
require_once('database.php');
$db = new db();?>
<div class="table-scrol">
    <h1 align="center">All Users</h1>

<div class="table-responsive">


    <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">
        <thead>

        <tr>

            <th>Customer_ID</th>
            <th>E-mail</th>
            <th>Nick Name</th>
            <th>First Name</th>
            <th>Last Name</th>
            
        </tr>
        </thead>
<?php

class TableRows extends RecursiveIteratorIterator { 
    function __construct($it) { 
        parent::__construct($it, self::LEAVES_ONLY); 
    }

    function current() {
        return "<td style='width: 150px; border: 1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() { 
        echo "<tr>"; 
    } 

    function endChildren() { 
        echo "</tr>" . "\n";
    } 
} 



$db->query("SELECT Customer_ID,Email,Nick_name,First_name,Last_name FROM Customers");
$db->execute();
 
    foreach(new TableRows(new RecursiveArrayIterator($db->resultset())) as $k=>$v) { 
        echo $v;
    }

$db = null;
?> 