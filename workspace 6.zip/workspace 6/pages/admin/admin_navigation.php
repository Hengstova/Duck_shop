<img class="main" src="/images/msin_01.gif">
<div class="logo"><a href="/admin"></a> <img src="/images/Webshop_1_03.gif"></div>
<form method="post">
<ul class="nav">
        <li><a href="/admin/orders">Orders</a></li>
        <li><a href="/admin/product/all">Products</a></li>
        <li><a href="/admin/view_users">Users</a></li>
        <li><a href="/admin/company/news">News</a></li>
        <li><a href="/admin/log_out">Log out</a></li>
</ul>
</form>

