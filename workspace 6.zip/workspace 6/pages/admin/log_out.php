<?php 
                $_SESSION = array();
                header('Location: '. HOST);
?>
<?php 
                $_SESSION = array();
                header('Location: '. HOST);
?>
