<?php 
require_once 'database.php';

$db = new db();

if(isset($_POST['detail'])) {
    
    $data['ID'] = $_POST['ID'];
    load::view('templates/details',$data);//přepsat ! 
    
}
else if(isset($_POST['delete'])) {
    $data['ID'] = $_POST['ID'];
    load::view('crud/delete',$data);
    
} 
else if(isset($_POST['update'])) {
    $data['ID'] = $_POST['ID'];
    load::view('crud/update',$data);
    
} 
else {
    



?>
<div class="table-scroll">
    <h1 align="center">All News</h1>

<div class="table-responsive"><!--this is used for responsive display in mobile and other devices-->


    <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">
        <thead>

        <tr>

            <th>News ID</th>
            <th>Content view</th>
            <th>Date</th>
            <th>Action</th>
            
            
          
        </thead>
<?php

$db->query("SELECT NEWS_ID, Content, Date FROM NEWS");//? join for category
$db->execute();
 
    foreach($db->resultset() as $k=>$v) { // for each - button
    echo '<tr><form method="post"><input type="hidden" name="ID" value="'. $v['NEWS_ID'] .'" />';
        foreach($v as $value) {
        echo '<td>'. 
        
        $value .
        
        '</td>';
            
        }
        

        echo "<td style='width: 150px; border: 1px solid black;'>
            <button type='submit' class='btn btn-danger' name='delete'>
                Delete
            </button>
            <button type='submit' class='btn btn-info' name='update'>Update</button>
<button type='submit' class='btn btn-primary m-r-1em' name='detail'>Detail</button></td></form></tr>";
   
         }
         
    ?>
   
                    
                   
<?php 
?>
             

             
             </table>
             </div>
             </div>
             <a href='/crud/create' class='btn btn-primary' name='create'>Create new product</a>
             </table>
             <?php 
             }$db = null;
             ?>