<?php
require "database.php";

$db = new db();

 if(isset($_POST['update_item'])) {
       try{   
     $db->query("UPDATE Company SET Description=:d,Name=:n,Contact=:c,) WHERE Company_ID=:id");
    $db->bind(':d',$_POST['description']);
    $db->bind(':n',$_POST['name']);
    $db->bind(':c',$_POST['contact']);
    $db->bind(':id',$_POST['ID']);
    
    $db->execute();
    if($db->execute()){
                echo "<div class='alert alert-success'>Information  updated.</div>";
            }else{
                echo "<div class='alert alert-danger'>Unable to update information.</div>";
            }



        
             
        }
        catch(PDOException $exception){
            die();
            echo "<div class='alert alert-success'>" . $exception->getMessage() ."</div>";
        }
    }
    
  
?>
<div class="table-scrol">
    <h1 align="center">Company information</h1>
    <div class="table-responsive">


    <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">
    
<tr>
    <td><input type="text" name="description" value="<?php echo $result['Description']; ?>" /></td>
    
     <?php
     /*<td><input type="text" name="news" value="<?php echo $result['News']; ?>" /></td>
     */?>
     <td><input type="text" name="name" value="<?php echo $result['Name']; ?>" /></td>
     <td><input type="text" name="contact" value="<?php echo $result['Contact']; ?>" /></td>
      
</tr>

</table>
<button type='submit' name="update_item" class='btn btn-primary'>Update</button>


<h2 class="header-text text-center">About Us</h2>
        <?php
        $db->query("SELECT * FROM Company");
        $db->execute();
       
        if($db->rowCount() > 0) {
            $single = $db->single();



                ?>
                <td><input type="text"class="pad text-center"> <?php echo $single["Description"]; ?></td>
                <?php
            }
        ?>
        