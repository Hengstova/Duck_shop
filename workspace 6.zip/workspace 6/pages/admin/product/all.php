<?php 
require_once 'database.php';

$db = new db();

    
  
    

 $data['ID'] = $_POST['ID'];
if(isset($_POST['delete'])) {

    load::view('crud/delete',$data);
    
} 
if(isset($_POST['detail'])) {
    
   
    load::view('templates/details',$data);
    
}

else if(isset($_POST['update'])) {
       
    load::view('crud/update',$data);
    
} else if(isset($_POST['update_item'])) {
       
        unset($_POST['update_item']);
       try {   
     $db->query("UPDATE Products SET Product_name=:n,image=:i,price=:p,Category_ID=:c,Quantity=:q) WHERE Product_ID=:id");
   
    $db->bind(':n',$_POST['name']);
    $db->bind(':i',$_POST['image']);
    $db->bind(':p',$_POST['price']);
    $db->bind(':c',$_POST['category']);
    $db->bind(':q',$_POST['quantity']);
    $db->bind(':id',$_POST['ID']);
    
    if($db->execute()){
                echo "<div class='alert alert-success'>Product updated.</div>";
            }else{
                echo "<div class='alert alert-danger'>Unable to update the product.</div>";
            }


    
         

        
             
        }
        catch(PDOException $exception){
            die();
            echo "<div class='alert alert-success'>" . $exception->getMessage() ."</div>";
        }
    }

else {
    



?>
<div class="table-scroll">
    <h1 align="center">All Products</h1>

<div class="table-responsive"><!--this is used for responsive display in mobile and other devices-->


    <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">
        <thead>

        <tr>

            <th>Product ID</th>
            <th>Name</th>
            <th>Price</th>
            <th>In Stock</th>
            <th>Action</th>
            
            
            
        </thead>
<?php

$db->query("SELECT Product_ID, Product_name,price,Quantity FROM Products");//? join for category
$db->execute();
 
    foreach($db->resultset() as $k=>$v) { // for each - button
    echo '<tr><form method="post"><input type="hidden" name="ID" value="'. $v['Product_ID'] .'" />';
        foreach($v as $value) {
        echo '<td>'. 
        
        $value .
        
        '</td>';
            
        }
        

        echo "<td style='width: 150px; border: 1px solid black;'>
            <button type='submit' class='btn btn-danger' name='delete'>
                Delete
            </button>
            <button type='submit' class='btn btn-info' name='update'>Update</button>
<button type='submit' class='btn btn-primary m-r-1em' name='detail'>Detail</button></td></form></tr>";
   
         }
         
    ?>
   
                    
                   
<?php 
?>
             

             
             </table>
             </div>
             </div>
             <a href='/crud/create' class='btn btn-primary' name='create'>Create new product</a>
             </table>
             <?php 
             }
             
             $db = null;
             
             $_POST = array();
             ?>