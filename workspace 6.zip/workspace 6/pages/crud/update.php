<?php 
    require_once 'database.php';
    $db = new db();
    
    
    $db->query("SELECT Product_ID, Product_name,price,Category_ID,Quantity,image FROM Products WHERE Product_ID=:id");//? join for category
    $db->bind(':id',$ID);
    $db->execute();
    
$result = $db->single();

if(isset($_POST['update_item']))
{  
     try{
            
            // DODELAt how to update 2 tables at once -catgeory
            $query = "UPDATE Products SET (Product_name:name,image:image,price:price,Quantity:quantity) WHERE(Product_ID:id)";
            $db->query($query);
            $db->bind(':name',htmlspecialchars(strip_tags($_POST['name'])));
            $db->bind(':fname',htmlspecialchars(strip_tags($_POST['image'])));
            $db->bind(':lname',htmlspecialchars(strip_tags($_POST['price'])));
            $db->bind(':email',htmlspecialchars(strip_tags($_POST['quantity'])));
           
         

            
            if($db->execute()){
                echo "<div class='alert alert-success'>Details were saved.</div>";
                //echo"<script>window.open('/')</script>";//change ? redirect to login or main page
            }else{
                echo "<div class='alert alert-danger'>Unable to save!.</div>";
            }

        }

            // show error
        catch(PDOException $exception){
            die('ERROR: ' . $exception->getMessage());
        }
 
    }
?>
</div>
<div class="table-scrol">
    <h1 align="center">Product Update</h1>

<div class="table-responsive">
    <form method="POST">  
    

    <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">
    

        <tr>

            <td>Product ID</td>
            <td>Name</td>
            <td>Image</td>
            <td>Price</td>
            <td>Category</td>
            <td>Quantity</td>
            
</tr>
<tr>
    <td><input type="text" name="ID" disabled="true" value="<?php echo $result['Product_ID']; ?>" /></td>
    
     <td><input type="text" name="name" value="<?php echo $result['Product_name']; ?>" /></td>
     <td><input type="text" name="image" value="<?php echo $result['image']; ?>" /></td>
     <td><input type="text" name="price" value="<?php echo $result['price']; ?>" /></td>
      <td>
                <?php
                
            // insert query
            $query = "SELECT * FROM Category";
            $db->query($query);
            $db->execute();
             
                if($db->rowCount() > 0) {
                $result = $db->resultset();
                
                echo "<select value='". $result['Category_ID'] ."' name='category' class='form-control'>";
                foreach ($result as $row) {
                
                echo "<option value='".$row['Category_ID']."'>" . $row['Type'] . "</option>";
                
                }
                echo "</select>";
               
                }
                else {
                    echo "<textarea name='categories' type='text' placeholder='Enter your categories seperated by comma'></textarea>";
                }
                 
                ?>
                </td>
     <td><input type="text" name="quantity" value="<?php echo $result['Quantity']; ?>" /></td>
</tr>

</table>
<button type='submit' name="update_item" class='btn btn-primary'>Update</button>
    </form>