<?php 
    require_once('database.php');
    $db = new db();
?>

<div class="container">

    <div class="page-header">
        <h1>Create Product</h1>
    </div>

    
    <?php
    if(isset($_POST['save_item'])){
        
// $target_dir = "~/workspace/images/";
// $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
// $uploadOk = 1;
// $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// // Check if image file is a actual image or fake image
//  $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
//     if($check !== false) {
//         echo "File is an image - " . $check["mime"] . ".";
//         $uploadOk = 1;
//     } else {
//         echo "File is not an image.";
//         $uploadOk = 0;
//     }

// // Check if file already exists
// if (file_exists($target_file)) {
//     echo "Sorry, file already exists.";
//     $uploadOk = 0;
// }
// // Check file size
// if ($_FILES["fileToUpload"]["size"] > 500000) {
//     echo "Sorry, your file is too large.";
//     $uploadOk = 0;
// }
// if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
// && $imageFileType != "gif" ) {
//     echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
//     $uploadOk = 0;
// }
// // Check if $uploadOk is set to 0 by an error
// if ($uploadOk == 0) {
//     echo "Sorry, your file was not uploaded.";
// // if everything is ok, try to upload file
// } else {
//     if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
//         echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
//     } else {
//         echo "Sorry, there was an error uploading your file.";
//     }
// }

        try{
            
            // insert query
            $query = "INSERT INTO Products (Product_name,price,image,Category_ID,Quantity) VALUES(:name,:price,:image,:category,:quantity)";
            $db->query($query);
            $db->bind(':name',htmlspecialchars(strip_tags($_POST['name'])));
            $db->bind(':price',htmlspecialchars(strip_tags($_POST['price'])));
            $db->bind(':image', '/images/'. 'someurl' .'.png');
            $db->bind(':category',htmlspecialchars(strip_tags($_POST['category'])));
            $db->bind(':quantity',htmlspecialchars(strip_tags($_POST['quantity'])));
         

            
            if($db->execute()){
                echo "<div class='alert alert-success'>Record was saved.</div>";
            }else{
                echo "<div class='alert alert-danger'>Unable to save record.</div>";
            }

        }

            // show error
        catch(PDOException $exception){
            die('ERROR: ' . $exception->getMessage());
        }
 
    }
        try{

            // insert query
            $query = "SELECT * FROM Category";
            $db->query($query);
            $db->execute();
             
        }
        catch(PDOException $exception){
            die('ERROR: ' . $exception->getMessage());
        }
         
  
 
    
    ?>

    <!-- html form here where the product information will be entered -->
    <form method="post">
        <table class='table table-hover table-responsive table-bordered'>
            
                
            <tr>
                <td>Product Name</td>
                <td><input type='text' name='name' class='form-control' required='required' /></td>
            </tr>
            <td>Price</td>
            <td><input type='number' name='price' class='form-control' required='required'/></td>
            </tr>
            <tr>
                <td>Image</td>
                <td><input type="file" name="image">Only JPG, JPEG, PNG & GIF files are allowed <br/></td>

            </tr>
            <tr>
                <td>Category</td>
                <td>
                <?php
                if($db->rowCount() > 0) {
                $result = $db->resultset();
                
                echo "<select name='category' class='form-control'>";
                foreach ($result as $row) {
                
                echo "<option value='".$row['Category_ID']."'>" . $row['Type'] . "</option>";
                
                }
                echo "</select>";
               
                }
                else {
                    echo "<textarea name='categories' type='text' placeholder='Enter your categories seperated by comma'></textarea>";
                }
                 
                ?>
                </td>
            </tr>
            <tr>
                <td>Quantity</td>
                <td><input name='quantity' type="number" class='form-control'/></td>
            </tr>

    
            <tr>
                <td></td>
                <td>
                    <button type='submit' name="save_item" class='btn btn-primary'>Save</button>
                    <a href='/admin/product/all' class='btn btn-danger'>Back to all products</a> <!-- redirect to index in CRUD folder-->
                </td>
            </tr>
        </table>
    </form>


</div>


<?php $db = null; ?>