<?php 
require_once 'database.php';

$db = new db();
        
if  (isset($_POST['delete'])){
    

$db->query("DELETE FROM Products WHERE Product_ID=:id");
$db->bind(':id',$ID);
$db->execute();
if($db->execute()){
                echo "<div class='alert alert-success'>Product was deleted.</div>";
            }else{
                echo "<div class='alert alert-danger'>Unable to delete the product.</div>";
            }

?> 

              
             
             <?php 
             } 
             $db = null;
             ?>
             