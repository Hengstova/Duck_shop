<?php

require_once('database.php');
$db = new db();

if (isset($_POST["first_contact"])) { 
    $ToEmail = 'barbora.hengstova@gmail.com'; 
    $mailheader = "From: " . $_POST["email"] . "\r\n";
    $MESSAGE_BODY = "Name: " . $_POST["name"]; 
    $MESSAGE_BODY .= "Email: " . $_POST["email"]; 
    $MESSAGE_BODY .= "Message: " . nl2br($_POST["comment"]); 
    mail($ToEmail, $MESSAGE_BODY, $mailheader) or die ("Failure"); 
?> 

 <div class='alert alert-success'>Thank you for your E-mail. You will hear from us soon.</div>

<?php 
} else {
    echo $error;



?>
    <div class="container">

        <div class="row">

            <div class="col-xl-8 offset-xl-2">

                <h2 class="header-text text-center">Contact</h1>

                <p class="lead">
                    Leave us a message and we will reply within 24 hours! If you would like to contact us through the phone, check the contact information below.
                </p>


                <form id="contact-form" method="post" role="form">

                    <div class="messages"></div>

                    <div class="controls">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="form_name">Firstname *</label>
                                    <input id="form_name" type="text" name="name" class="form-control" placeholder="Please enter your firstname *" required="required"
                                        data-error="Firstname is required.">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="form_lastname">Lastname *</label>
                                    <input id="form_lastname" type="text" name="surname" class="form-control" placeholder="Please enter your lastname *" required="required"
                                        data-error="Lastname is required.">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="form_email">Email *</label>
                                    <input id="form_email" type="email" name="email" class="form-control" placeholder="Please enter your email *" required="required"
                                        data-error="Valid email is required.">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="form_phone">Phone</label>
                                    <input id="form_phone" type="tel" name="phone" class="form-control" placeholder="Please enter your phone">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="form_message">Message *</label>
                            <textarea id="form_message" name="message" class="form-control" placeholder="Message for me *" rows="4" required="required"
                                data-error="Please, leave us a message."></textarea>
                            <div class="help-block with-errors"></div>
                        </div>


                        <!--<div class="form-group">
                            <div class="g-recaptcha" data-sitekey="6LcFG1YUAAAAAHQWROb92P3ZufuG5IAoc2kjtSEP" data-callback="verifyRecaptchaCallback" data-expired-callback="expiredRecaptchaCallback"></div>
                            <input class="form-control d-none" data-recaptcha="true" required data-error="Please complete the Captcha">
                            <div class="help-block with-errors"></div>
                        </div>-->


                        <button type="submit" name="first_contact" class="btn btn-success btn-send" >
                        Send message
                        </button>

                        <p class="text-muted">
                            <strong>
                                *
                            </strong> 
                            These fields are required.
                        </p>

                    </div>

                </form>

            </div>
            <!-- /.8 -->

        </div>
        <!-- /.row-->

    </div>
    <!-- /.container-->

 <?php
}
$db->query("SELECT Name,Contact, Street, Country, Postal_code_ID FROM Company");
$db->execute();
$result = $db->resultset();
if($db->rowCount() > 0)
{
    foreach ($result as $row) {


        ?>
        <div class="helvetica" style="width:6O%" align="center">
            <p> <?php echo $row["Name"]; ?></p>
            <p> <?php echo $row["Contact"]; ?></p>
            <p> <?php echo $row["Street"]; ?></p>
            <p> <?php echo $row["Country"]; ?></p>
            <p> <?php echo $row["Phone"]; ?></p>
        </div>

        <?php
    }
}
$db = null;
?>
  <script src='https://www.google.com/recaptcha/api.js'></script>

