<?php 
require("forms/extention_functions.php");
load::view('user/create_user');