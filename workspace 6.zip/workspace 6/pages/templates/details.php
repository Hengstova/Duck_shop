
<?php 
    require_once 'database.php';
    $db = new db();
    $db->query("SELECT Product_ID, Product_name,price,Category_ID,Quantity,image FROM Products WHERE Product_ID=:id");//? join for category
    $db->bind(':id',$ID);
    $db->execute();
    
$result = $db->single();

?>
</div>
<div class="table-scrol">
    <h1 align="center">Product Detail</h1>

<div class="table-responsive">


    <table class="table table-bordered table-hover table-striped" style="table-layout: fixed">
        <tdead>

        <tr>

            <td>Product ID</td>
            <td>Name</td>
            <td>Image</td>
            <td>Price</td>
            <td>Category</td>
            <td>Quantity</td>
            
</tr>
<tr>
    <td><?php echo $result['Product_ID']; ?></td>
     <td><?php echo $result['Product_name']; ?></td>
     <td><?php echo $result['image'] ? "<img src='/" . $result['image'] . "' style='width:100%;' />" : "No image found."; ?></td>
     <td><?php echo $result['price']; ?></td>
     <td><?php 
     $db->query('SELECT * FROM Category WHERE Category_ID=:id');
     $db->bind(':id',$result['Category_ID']);
     $db->execute();
     echo $db->single()['Type']; ?></td>
     <td><?php echo $result['Quantity']; ?></td>
</tr>
</tdead>


