<?php 

echo 'recommendations works!';

?>