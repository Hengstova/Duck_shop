  <img class="main" src="/images/msin_01.gif">
  <ul class="nav" align="right">
        <li><a href="/#">Home</a></li>
        <li><a href="/#allproducts">Products</a></li>
        <li><a href="/contact">Contact</a></li>
        <li><a href="/admin">Admin Access</a></li>
        <li><a href="/user/login">Log in</a></li>
        <li><a href="/shop?action=add$id=">
          <img src="/images/Webshop_1_06.gif" /></a></li>

    </ul>
     <div class="logo"><a href="/"></a> <img src="/images/Webshop_1_03_transp.png" /></div>
    <!--    <ul class="nav" align="right">-->

    <!--    <li><a href="#">Home</a></li>-->
    <!--    <li><a href="#allproducts">Products</a></li>-->
    <!--    <li><a href="#contact">Contact</a></li>-->
    <!--    <li><a href= "Login/admin_login.php">Admin Access</a></li>-->
    <!--    <li><a href="shop.php?action=add$id="><img src="images/Webshop_1_06.gif" /></a></li>-->


    <!--</ul>-->
    