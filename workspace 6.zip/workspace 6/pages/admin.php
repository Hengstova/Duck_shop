<?php 

require_once 'database.php';
   $db = new db();

if(isset($_POST['admin_login'])) //this will tell us what to do if some data has been post through form with button.
{
    $admin_name = $_POST['admin_name'];
    $admin_pass = $_POST['admin_pass'];

   $db->query("select * from Admin where Name=:name AND Password=:pass");
   $db->bind(':name',htmlspecialchars(strip_tags($admin_name)));
   $db->bind(':pass',htmlspecialchars(strip_tags($admin_pass)));
   $db->execute();
   

    if($db->rowCount() > 0)
    {
        $result = $db->resultset();
        $_SESSION['admin'] = true;

  header('Location: '. HOST .'admin/product/all');
    //view all orrders
    }
    else {
        echo "<script>alert('Admin Details are incorrect!')</script>";
        
    }
  
} else {
    load::view('admin/login');
    
}
  $db = null;
?>
