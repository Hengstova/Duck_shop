<?php


function btn($text,$color) {
     ?>
         <button class="btn btn-<?php echo $color; ?>"><?php echo $text; ?></button>
    <?php  
}
function input($name,$type = "text" ,$value = '',$placeholder = '') {
    $id = $name . '-' . $type;
     ?>
     
     <label for="<?php echo $id; ?>"> <?php echo $name; ?></label>
         <input id="<?php echo $id; ?>" name="<?php echo $name; ?>" type="<?php echo $type; ?>" value="<?php echo $value; ?>" placeholder="<?php echo $placeholder; ?>" class="form-control" />
    <?php  
}
// just for example on how can they can nest themselves making them as big as you want
/*
    $object_of_values = {
        $key => $value, 
    }
    <input name="$key", value="$value" />
*/
function form($object_of_values,$string_action) {
        
     ?>
     <form method="post" action="<?php echo $string_action; ?>"> 
     <?php 
     foreach($object_of_values as $key => $value ) {
          input($key,$value['type'],$value['value'],$value['placeholder']);
            
        }
        btn('Save','danger');
    ?>
        
    </form>
    <?php 
    
}

function console($what) {
    ?>
    <script>
        console.log(`<?php echo $what; ?>`);
    </script>
    
    <?php 
}

?>