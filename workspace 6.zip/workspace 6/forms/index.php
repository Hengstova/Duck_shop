<?php

include_once('./extention_functions.php'); 
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Rubby the Duck </title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel= stylesheet type="text/css" href="style.css">
</head>

    <body>
<?php 
$form_structure = array(
        "Email" => array(
            "value" => "email@email.email",
            "placeholder" => "Email *",
            "type" => "email"
             ),
        "Password" => array(
            "value" => "",
            "placeholder" => "Password *",
            "type" => "password"
             )
    );

?>
<div class="jumbotron container">
<?php
form($form_structure, '/index.php'); 
?>
<p>So this code litearally generates the coresponding form.</p>
</div>


    </body>
</html>