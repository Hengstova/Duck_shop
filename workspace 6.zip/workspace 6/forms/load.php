<?php 

class load {
    static function view($viewFile,$viewVars = array()){
        extract(is_string($viewVars )?explode($viewVars,','):$viewVars);
        $viewFileCheck = explode(".",$viewFile);
        if(!isset($viewFileCheck[1])){
            $viewFile.= ".php";
        }
        $viewFile = str_replace("::","/", $viewFile);
        $filename =  "pages/{$viewFile}";
        if(file_exists($filename)){
            require_once $filename;
        }
        else {
            die("trying to load non existing view");
        }
    }
}
?>